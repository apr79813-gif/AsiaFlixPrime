import React, { useState, useEffect } from 'react';
import { DramaItem, WatchlistStatus } from '../types/drama';
import { 
  Play, 
  Bookmark, 
  BookmarkCheck, 
  Info, 
  ChevronLeft, 
  ChevronRight, 
  Sparkles, 
  Star,
  Copy,
  Check
} from 'lucide-react';

interface HeroBannerProps {
  featuredDramas: DramaItem[];
  onSelectDrama: (drama: DramaItem) => void;
  onToggleWatchlist: (drama: DramaItem, status?: WatchlistStatus) => void;
  isWatchlisted: (dramaId: string) => boolean;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({
  featuredDramas,
  onSelectDrama,
  onToggleWatchlist,
  isWatchlisted,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [copied, setCopied] = useState(false);

  const activeDrama = featuredDramas[currentIndex] || featuredDramas[0];

  useEffect(() => {
    if (featuredDramas.length <= 1) return;
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % featuredDramas.length);
    }, 8000);
    return () => clearInterval(timer);
  }, [featuredDramas.length]);

  const handleCopyLink = () => {
    navigator.clipboard.writeText("https://asiaflixprimeofficial.netlify.app/");
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  if (!activeDrama) return null;

  const inWatchlist = isWatchlisted(activeDrama.id);

  return (
    <section className="relative overflow-hidden border-b border-white/[0.08] min-h-[520px] lg:min-h-[580px] flex items-center">
      {/* Cinematic Backdrop Image with Dark Vignette */}
      <div className="absolute inset-0 z-0">
        <img
          src={activeDrama.backdrop || activeDrama.poster}
          alt={activeDrama.title}
          className="w-full h-full object-cover object-center filter brightness-[0.4] transition-all duration-1000 scale-105"
        />
        {/* Gradients */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#08080c] via-[#08080c]/60 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#08080c] via-[#08080c]/80 to-transparent max-w-4xl" />
        <div className="absolute inset-x-0 bottom-0 h-32 bg-gradient-to-t from-[#08080c] to-transparent" />
      </div>

      <div className="relative z-20 max-w-7xl mx-auto px-4 sm:px-6 py-12 lg:py-16 w-full">
        {/* Top VIP Badge */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/[0.06] border border-white/10 backdrop-blur-md text-xs text-zinc-300 font-semibold mb-6 shadow-sm">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>Weekend Mega Lineup is Active!</span>
          <span className="text-zinc-500">·</span>
          <span className="text-amber-400 font-bold flex items-center gap-1">
            <Sparkles className="w-3 h-3" /> VIP High Speed
          </span>
        </div>

        <div className="max-w-2xl">
          {/* Audio & Category tags */}
          <div className="flex flex-wrap items-center gap-2 mb-3">
            <span className="bg-[#e50914] text-white text-[11px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded shadow-sm">
              {activeDrama.defaultAudio}
            </span>
            <span className="bg-white/10 text-white text-[11px] font-bold px-2 py-0.5 rounded backdrop-blur-sm">
              {activeDrama.category}
            </span>
            <span className="text-zinc-400 text-xs font-semibold">
              {activeDrama.releaseYear}
            </span>
            <span className="text-zinc-500">·</span>
            <div className="flex items-center text-amber-400 text-xs font-bold gap-1">
              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
              <span>{activeDrama.rating}</span>
            </div>
            <span className="text-zinc-500">·</span>
            <span className="text-sky-400 text-xs font-bold">
              {activeDrama.scheduleInfo}
            </span>
          </div>

          {/* Main Title */}
          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black text-white tracking-tight leading-[1.1] mb-4 text-balance">
            {activeDrama.title}
          </h1>

          {/* Synopsis */}
          <p className="text-zinc-300 text-sm sm:text-base leading-relaxed line-clamp-3 mb-8 max-w-xl text-balance">
            {activeDrama.synopsis}
          </p>

          {/* CTA Action Buttons */}
          <div className="flex flex-wrap items-center gap-3">
            <a
              href={activeDrama.telegramUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-[#e50914] to-[#ff2b54] text-white text-sm font-black shadow-[0_0_25px_rgba(229,9,20,0.5)] hover:shadow-[0_0_35px_rgba(229,9,20,0.8)] hover:scale-[1.02] active:scale-[0.98] transition-all"
            >
              <Play className="w-4 h-4 fill-white" />
              <span>Open in Telegram</span>
            </a>

            <button
              onClick={() => onSelectDrama(activeDrama)}
              className="flex items-center gap-2 px-5 py-3 rounded-xl bg-white/[0.08] hover:bg-white/[0.14] text-white text-sm font-bold border border-white/10 backdrop-blur-md transition-all hover:scale-[1.02]"
            >
              <Info className="w-4 h-4 text-zinc-300" />
              <span>Episodes & Audio</span>
            </button>

            <button
              onClick={() => onToggleWatchlist(activeDrama)}
              className={`flex items-center gap-2 px-4 py-3 rounded-xl border text-sm font-bold backdrop-blur-md transition-all ${
                inWatchlist
                  ? 'bg-amber-500/20 border-amber-500/40 text-amber-300'
                  : 'bg-white/[0.04] hover:bg-white/[0.08] border-white/10 text-zinc-300 hover:text-white'
              }`}
              title={inWatchlist ? 'In your Watchlist' : 'Add to Watchlist'}
            >
              {inWatchlist ? (
                <>
                  <BookmarkCheck className="w-4 h-4 text-amber-400" />
                  <span className="hidden sm:inline">Saved</span>
                </>
              ) : (
                <>
                  <Bookmark className="w-4 h-4" />
                  <span className="hidden sm:inline">Watchlist</span>
                </>
              )}
            </button>

            <button
              onClick={handleCopyLink}
              className="flex items-center gap-1.5 px-3.5 py-3 rounded-xl bg-white/[0.03] hover:bg-white/[0.08] text-zinc-400 hover:text-zinc-200 text-xs font-semibold border border-white/[0.08] transition-all"
              title="Copy Portal Invite Link"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied!' : 'Copy Invite'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Slide Navigation Controls */}
      {featuredDramas.length > 1 && (
        <div className="absolute bottom-6 right-6 z-30 flex items-center gap-2">
          <button
            onClick={() => setCurrentIndex((prev) => (prev - 1 + featuredDramas.length) % featuredDramas.length)}
            className="p-2 rounded-lg bg-black/60 hover:bg-black/90 border border-white/10 text-white backdrop-blur-sm transition-all"
            aria-label="Previous Featured Drama"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <div className="flex items-center gap-1.5 px-2">
            {featuredDramas.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrentIndex(i)}
                className={`h-1.5 rounded-full transition-all ${
                  currentIndex === i ? 'w-6 bg-[#e50914]' : 'w-2 bg-white/30 hover:bg-white/50'
                }`}
                aria-label={`Go to slide ${i + 1}`}
              />
            ))}
          </div>
          <button
            onClick={() => setCurrentIndex((prev) => (prev + 1) % featuredDramas.length)}
            className="p-2 rounded-lg bg-black/60 hover:bg-black/90 border border-white/10 text-white backdrop-blur-sm transition-all"
            aria-label="Next Featured Drama"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      )}
    </section>
  );
};
