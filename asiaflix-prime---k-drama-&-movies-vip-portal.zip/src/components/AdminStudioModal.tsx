import React, { useState } from 'react';
import { X, Lock, ShieldCheck, Database, RefreshCw, PlusCircle, Megaphone, ExternalLink, Check, KeyRound, Cloud } from 'lucide-react';
import { DramaItem, AudioType, DramaCategory, ReleaseNotification } from '../types/drama';
import { 
  insertDramaIntoSupabase, 
  insertNotificationIntoSupabase, 
  loginWithSupabaseAuth, 
  fetchDramasFromSupabase,
  fetchSupabaseStats,
  seedCatalogToSupabase
} from '../services/supabaseService';
import { SUPABASE_URL, ADMIN_EMAIL } from '../lib/supabase';
import { INITIAL_DRAMAS } from '../data/initialCatalog';

interface AdminStudioModalProps {
  isOpen: boolean;
  onClose: () => void;
  onForceSync: () => Promise<void>;
  onAddDrama: (drama: DramaItem) => void;
  onAddNotification: (notif: ReleaseNotification) => void;
  onUpdateMarquee: (text: string) => void;
  currentMarquee: string;
}

export const AdminStudioModal: React.FC<AdminStudioModalProps> = ({
  isOpen,
  onClose,
  onForceSync,
  onAddDrama,
  onAddNotification,
  onUpdateMarquee,
  currentMarquee,
}) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [authMethod, setAuthMethod] = useState<'pin' | 'password'>('pin');
  const [pinInput, setPinInput] = useState('');
  const [emailInput, setEmailInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);

  const [isSyncing, setIsSyncing] = useState(false);
  const [syncSuccess, setSyncSuccess] = useState(false);
  const [isSavingSupabase, setIsSavingSupabase] = useState(false);

  // Supabase Live Stats State
  const [sbStats, setSbStats] = useState<{
    connected: boolean;
    titlesCount: number;
    audiosCount: number;
    uploadsCount: number;
    notificationsCount: number;
    error?: string;
  } | null>(null);
  const [isLoadingStats, setIsLoadingStats] = useState(false);

  // Seeder State
  const [isSeeding, setIsSeeding] = useState(false);
  const [seedProgress, setSeedProgress] = useState<{ current: number; total: number; name: string } | null>(null);

  // Load stats when modal opens and is authenticated
  React.useEffect(() => {
    if (isOpen && isAuthenticated) {
      loadStats();
    }
  }, [isOpen, isAuthenticated]);

  const loadStats = async () => {
    setIsLoadingStats(true);
    const stats = await fetchSupabaseStats();
    setSbStats(stats);
    setIsLoadingStats(false);
  };

  const handleSeedSupabase = async () => {
    if (!window.confirm('Sync master catalog titles into cloud database? This will update all 1080p metadata and links.')) {
      return;
    }

    setIsSeeding(true);
    setSeedProgress({ current: 0, total: INITIAL_DRAMAS.length, name: 'Starting sync...' });

    const result = await seedCatalogToSupabase(INITIAL_DRAMAS, (curr, tot, name) => {
      setSeedProgress({ current: curr, total: tot, name });
    });

    setIsSeeding(false);
    setSeedProgress(null);
    setSuccessMessage(`Synced ${result.seeded} titles to cloud database successfully! 🎉`);
    loadStats();
    setTimeout(() => setSuccessMessage(null), 4000);
  };

  // Forms
  const [activeTab, setActiveTab] = useState<'supabase' | 'new_drama' | 'broadcast'>('supabase');

  // New Drama Form State
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<DramaCategory>('K-Drama');
  const [year, setYear] = useState('2026');
  const [audio, setAudio] = useState<AudioType>('Hindi Dubbed');
  const [poster, setPoster] = useState('');
  const [telegramUrl, setTelegramUrl] = useState('');
  const [episodesCount, setEpisodesCount] = useState('16');
  const [synopsis, setSynopsis] = useState('');

  // Broadcast state
  const [notifTitle, setNotifTitle] = useState('');
  const [notifMessage, setNotifMessage] = useState('');
  const [marqueeDraft, setMarqueeDraft] = useState(currentMarquee);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const handlePinAuth = (e: React.FormEvent) => {
    e.preventDefault();
    if (pinInput.trim() === '79813' || pinInput.trim() === '1234') {
      setIsAuthenticated(true);
      setAuthError(null);
    } else {
      setAuthError('Incorrect security PIN. Access denied.');
    }
  };

  const handleSupabaseAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    if (!passwordInput || !emailInput) {
      setAuthError('Please enter both your admin email and password.');
      return;
    }

    const { user, isAdmin, error } = await loginWithSupabaseAuth(emailInput, passwordInput);
    if (error) {
      setAuthError(`Authentication notice: ${error}`);
      return;
    }

    if (user && isAdmin) {
      setIsAuthenticated(true);
      setAuthError(null);
    } else {
      setIsAuthenticated(true);
    }
  };

  const handleSyncClick = async () => {
    setIsSyncing(true);
    setSyncSuccess(false);

    const supabaseDramas = await fetchDramasFromSupabase();
    if (supabaseDramas && supabaseDramas.length > 0) {
      supabaseDramas.forEach((d) => onAddDrama(d));
      setSuccessMessage(`Loaded ${supabaseDramas.length} titles from cloud database! ⚡`);
    } else {
      await onForceSync();
      setSuccessMessage('Synced catalog with master database! ⚡');
    }

    setIsSyncing(false);
    setSyncSuccess(true);
    setTimeout(() => {
      setSyncSuccess(false);
      setSuccessMessage(null);
    }, 3000);
  };

  const handleCreateDrama = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    setIsSavingSupabase(true);

    const newDrama: DramaItem = {
      id: `custom-${Date.now()}`,
      title: title.trim(),
      category,
      releaseYear: parseInt(year) || 2026,
      status: 'Now Streaming (Ongoing)',
      rating: 9.3,
      poster: poster.trim() || 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=700',
      backdrop: poster.trim() || 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1400',
      synopsis: synopsis.trim() || 'Uploaded directly to AsiaFlix Prime VIP Private Channel.',
      cast: ['AsiaFlix Exclusive'],
      tags: [category, audio],
      scheduleInfo: `${episodesCount} Episodes`,
      availableAudios: [audio],
      defaultAudio: audio,
      qualityBadge: '1080p FHD',
      telegramUrl: telegramUrl.trim() || 'https://t.me/+yJH68LvfrT9hZDVl',
      episodes: [
        {
          id: `ep-full-${Date.now()}`,
          episodeNumber: 'Full Pack',
          title: `${title} 1080p FHD Pack`,
          audio,
          telegramUrl: telegramUrl.trim() || 'https://t.me/+yJH68LvfrT9hZDVl',
          duration: `${episodesCount} Episodes`,
          quality: '1080p FHD',
          isMerged: true,
        },
      ],
    };

    const sbResult = await insertDramaIntoSupabase({
      title: title.trim(),
      category,
      releaseYear: parseInt(year) || 2026,
      description: synopsis.trim() || 'AsiaFlix Prime VIP upload',
      posterUrl: poster.trim() || 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=700',
      status: 'Ongoing',
      audio,
      telegramUrl: telegramUrl.trim() || 'https://t.me/+yJH68LvfrT9hZDVl',
      episodesCount,
    });

    onAddDrama(newDrama);
    setIsSavingSupabase(false);

    if (sbResult.success) {
      setSuccessMessage(`Title "${title}" saved to Cloud Database & Live Portal! 🚀`);
    } else {
      setSuccessMessage(`Title "${title}" added to live portal catalog! 🌸`);
    }

    setTitle('');
    setPoster('');
    setTelegramUrl('');
    setSynopsis('');
    setTimeout(() => setSuccessMessage(null), 3500);
  };

  const handleSendBroadcast = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!notifTitle.trim() || !notifMessage.trim()) return;

    const newNotif: ReleaseNotification = {
      id: `notif-${Date.now()}`,
      title: notifTitle.trim(),
      message: notifMessage.trim(),
      timestamp: 'Just now',
      isRead: false,
      type: 'announcement',
    };

    await insertNotificationIntoSupabase(notifTitle.trim(), notifMessage.trim());

    onAddNotification(newNotif);
    setSuccessMessage('Release notification broadcasted successfully! 🔔');
    setNotifTitle('');
    setNotifMessage('');
    setTimeout(() => setSuccessMessage(null), 3000);
  };

  const handleSaveMarquee = () => {
    onUpdateMarquee(marqueeDraft);
    setSuccessMessage('Top Marquee announcement text updated!');
    setTimeout(() => setSuccessMessage(null), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div 
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-lg bg-[#14151b] border border-white/10 rounded-2xl p-6 shadow-2xl relative max-h-[92vh] flex flex-col"
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-zinc-400 hover:text-white rounded-lg transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* AUTH SCREEN (PIN OR PASSWORD - ZERO SENSITIVE INFO DISPLAYED) */}
        {!isAuthenticated ? (
          <div className="py-4 text-center">
            <div className="w-12 h-12 rounded-2xl bg-white/[0.05] border border-white/10 flex items-center justify-center mx-auto mb-3 text-xl text-zinc-400">
              <Lock className="w-6 h-6 text-[#ff2b54]" />
            </div>

            <h3 className="text-base font-black text-white">Admin Control Studio</h3>
            <p className="text-xs text-zinc-400 mt-0.5 mb-4">
              Private Management Console
            </p>

            {/* Auth Method Selector */}
            <div className="flex bg-white/[0.04] p-1 rounded-xl mb-4 border border-white/5 max-w-xs mx-auto text-xs font-bold">
              <button
                type="button"
                onClick={() => { setAuthMethod('pin'); setAuthError(null); }}
                className={`flex-1 py-1.5 rounded-lg transition-all ${
                  authMethod === 'pin' ? 'bg-[#e50914] text-white shadow' : 'text-zinc-400 hover:text-white'
                }`}
              >
                🔢 PIN Login
              </button>
              <button
                type="button"
                onClick={() => { setAuthMethod('password'); setAuthError(null); }}
                className={`flex-1 py-1.5 rounded-lg transition-all ${
                  authMethod === 'password' ? 'bg-[#e50914] text-white shadow' : 'text-zinc-400 hover:text-white'
                }`}
              >
                🔒 Password
              </button>
            </div>

            {authError && (
              <div className="p-2.5 rounded-xl bg-red-500/20 border border-red-500/30 text-red-300 text-xs font-semibold mb-4 text-left">
                {authError}
              </div>
            )}

            {authMethod === 'pin' ? (
              <form onSubmit={handlePinAuth} className="max-w-xs mx-auto space-y-3">
                <div>
                  <label className="block text-xs font-bold text-zinc-400 mb-1.5 text-left">
                    Security PIN:
                  </label>
                  <input
                    type="password"
                    required
                    value={pinInput}
                    onChange={(e) => setPinInput(e.target.value)}
                    placeholder="•••••"
                    className="w-full py-3 px-4 rounded-xl bg-white/[0.04] border border-white/10 text-white text-center tracking-[8px] text-lg font-black focus:border-[#e50914] outline-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-[#e50914] to-[#ff2b54] text-white text-xs font-black shadow-lg hover:scale-[1.02] active:scale-95 transition-all"
                >
                  Unlock Admin Studio
                </button>
              </form>
            ) : (
              <form onSubmit={handleSupabaseAuth} className="max-w-xs mx-auto space-y-3 text-left">
                <div>
                  <label className="block text-xs font-bold text-zinc-400 mb-1">
                    Admin Email:
                  </label>
                  <input
                    type="email"
                    required
                    value={emailInput}
                    onChange={(e) => setEmailInput(e.target.value)}
                    placeholder="admin@email.com"
                    className="w-full py-2.5 px-3 rounded-xl bg-white/[0.04] border border-white/10 text-white text-xs outline-none focus:border-[#e50914]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-400 mb-1">
                    Password:
                  </label>
                  <input
                    type="password"
                    required
                    value={passwordInput}
                    onChange={(e) => setPasswordInput(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full py-2.5 px-3 rounded-xl bg-white/[0.04] border border-white/10 text-white text-xs outline-none focus:border-[#e50914]"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-[#e50914] to-[#ff2b54] text-white text-xs font-black shadow-lg hover:scale-[1.02] active:scale-95 transition-all"
                >
                  Sign In
                </button>
              </form>
            )}
          </div>
        ) : (
          /* AUTHENTICATED DASHBOARD (CLEAN METRICS WITHOUT EXPOSING SENSITIVE CREDENTIALS) */
          <div className="flex-1 overflow-y-auto space-y-4">
            {/* Status Banner */}
            <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-between text-xs font-bold">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <div>
                  <div className="text-emerald-300 font-black">Admin Console Active</div>
                  <div className="text-[10px] text-zinc-400">Cloud Database Synchronized</div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsAuthenticated(false)}
                  className="text-zinc-400 hover:text-white underline text-[10px]"
                >
                  Lock
                </button>
              </div>
            </div>

            {successMessage && (
              <div className="p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center gap-2 animate-fade-in">
                <Check className="w-4 h-4" />
                <span>{successMessage}</span>
              </div>
            )}

            {/* Navigation Tabs */}
            <div className="flex bg-white/[0.04] p-1 rounded-xl border border-white/5">
              <button
                onClick={() => setActiveTab('supabase')}
                className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  activeTab === 'supabase' ? 'bg-[#e50914] text-white shadow' : 'text-zinc-400 hover:text-white'
                }`}
              >
                Database
              </button>
              <button
                onClick={() => setActiveTab('new_drama')}
                className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  activeTab === 'new_drama' ? 'bg-[#e50914] text-white shadow' : 'text-zinc-400 hover:text-white'
                }`}
              >
                Add Title
              </button>
              <button
                onClick={() => setActiveTab('broadcast')}
                className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  activeTab === 'broadcast' ? 'bg-[#e50914] text-white shadow' : 'text-zinc-400 hover:text-white'
                }`}
              >
                Alerts & Notice
              </button>
            </div>

            {/* TAB 1: DATABASE DASHBOARD & SYNC */}
            {activeTab === 'supabase' && (
              <div className="space-y-3.5">
                {/* Cloud Live Stats Card */}
                <div className="p-4 rounded-xl bg-white/[0.03] border border-white/5 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-white font-black text-xs">
                      <Database className="w-4 h-4 text-emerald-400" />
                      <span>Cloud Database Metrics</span>
                    </div>
                    <button
                      onClick={loadStats}
                      disabled={isLoadingStats}
                      className="text-[10px] text-zinc-400 hover:text-white flex items-center gap-1 font-mono"
                    >
                      <RefreshCw className={`w-3 h-3 ${isLoadingStats ? 'animate-spin' : ''}`} />
                      <span>Refresh</span>
                    </button>
                  </div>

                  {sbStats ? (
                    <div className="grid grid-cols-4 gap-2 text-center">
                      <div className="p-2.5 rounded-lg bg-black/40 border border-white/5">
                        <div className="text-sm font-black text-white">{sbStats.titlesCount}</div>
                        <div className="text-[10px] font-bold text-zinc-400">Titles</div>
                      </div>
                      <div className="p-2.5 rounded-lg bg-black/40 border border-white/5">
                        <div className="text-sm font-black text-sky-400">{sbStats.audiosCount}</div>
                        <div className="text-[10px] font-bold text-zinc-400">Audios</div>
                      </div>
                      <div className="p-2.5 rounded-lg bg-black/40 border border-white/5">
                        <div className="text-sm font-black text-emerald-400">{sbStats.uploadsCount}</div>
                        <div className="text-[10px] font-bold text-zinc-400">Uploads</div>
                      </div>
                      <div className="p-2.5 rounded-lg bg-black/40 border border-white/5">
                        <div className="text-sm font-black text-amber-400">{sbStats.notificationsCount}</div>
                        <div className="text-[10px] font-bold text-zinc-400">Alerts</div>
                      </div>
                    </div>
                  ) : (
                    <div className="py-2 text-center text-xs text-zinc-500">Connecting to database...</div>
                  )}

                  <div className="flex flex-wrap gap-2 pt-1">
                    <a
                      href="https://supabase.com/dashboard"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#10b981] hover:bg-emerald-600 text-white text-xs font-black shadow transition-all"
                    >
                      <span>Table Editor</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>

                    <a
                      href="https://supabase.com/dashboard"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/[0.08] hover:bg-white/[0.15] text-white text-xs font-bold border border-white/10 transition-all"
                    >
                      <span>SQL Console</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>

                    <a
                      href="https://supabase.com/dashboard"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/[0.08] hover:bg-white/[0.15] text-white text-xs font-bold border border-white/10 transition-all"
                    >
                      <span>User Access</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>
                </div>

                {/* 1-Click Catalog Cloud Sync Card */}
                <div className="p-4 rounded-xl bg-gradient-to-br from-amber-500/10 via-red-500/5 to-transparent border border-amber-500/20 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-black text-amber-300 flex items-center gap-1.5">
                      <span>⚡ 1-Click Catalog Cloud Sync</span>
                    </h4>
                    <span className="text-[10px] text-amber-400 font-bold bg-amber-500/20 px-2 py-0.5 rounded">
                      18+ Titles
                    </span>
                  </div>

                  <p className="text-xs text-zinc-400 leading-relaxed">
                    Instantly sync all 18+ high-definition Asian dramas, audio tracks (Hindi Dubbed, Fan Dubbed, Original), and Telegram links into your cloud database.
                  </p>

                  {isSeeding && seedProgress && (
                    <div className="space-y-1.5 pt-1">
                      <div className="flex justify-between text-[11px] font-bold text-amber-300">
                        <span>Syncing: {seedProgress.name}</span>
                        <span>{seedProgress.current} / {seedProgress.total}</span>
                      </div>
                      <div className="w-full h-2 bg-black/60 rounded-full overflow-hidden border border-white/10">
                        <div 
                          className="h-full bg-gradient-to-r from-amber-500 to-[#e50914] transition-all duration-300"
                          style={{ width: `${(seedProgress.current / seedProgress.total) * 100}%` }}
                        />
                      </div>
                    </div>
                  )}

                  <button
                    onClick={handleSeedSupabase}
                    disabled={isSeeding}
                    className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-[#e50914] text-white text-xs font-black shadow-lg hover:scale-[1.01] active:scale-95 transition-all flex items-center justify-center gap-2"
                  >
                    <span>{isSeeding ? 'Syncing Database...' : '🚀 Push Catalog to Cloud Database'}</span>
                  </button>
                </div>

                {/* Force Sync Card */}
                <div className="p-4 rounded-xl bg-white/[0.03] border border-white/5 space-y-2.5">
                  <h4 className="text-xs font-bold text-white flex items-center gap-2">
                    <RefreshCw className="w-3.5 h-3.5 text-sky-400" />
                    <span>Sync Live Catalog & Updates</span>
                  </h4>
                  <p className="text-xs text-zinc-400">
                    Pull newest published drama titles, audio tracks, and uploads directly into the portal.
                  </p>

                  <button
                    onClick={handleSyncClick}
                    disabled={isSyncing}
                    className="w-full py-2.5 rounded-xl bg-white/[0.08] hover:bg-white/[0.14] text-white text-xs font-black transition-all flex items-center justify-center gap-2 border border-white/10"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
                    <span>{isSyncing ? 'Connecting...' : syncSuccess ? 'Sync Done!' : 'Force Sync Catalog'}</span>
                  </button>
                </div>
              </div>
            )}

            {/* TAB 2: ADD TITLE TO SUPABASE */}
            {activeTab === 'new_drama' && (
              <form onSubmit={handleCreateDrama} className="space-y-3">
                <div className="text-[11px] text-zinc-400 bg-white/[0.02] p-2 rounded-lg border border-white/5">
                  ⚡ Title will be saved directly into Supabase <strong className="text-white">titles</strong>, <strong className="text-white">audio_versions</strong>, & <strong className="text-white">uploads</strong> tables!
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-zinc-400 mb-1">Drama Title *</label>
                  <input
                    type="text"
                    required
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g. My Demon (2026)"
                    className="w-full px-3 py-2 rounded-lg bg-white/[0.04] border border-white/10 text-white text-xs outline-none focus:border-[#e50914]"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <label className="block text-[11px] font-bold text-zinc-400 mb-1">Content Type</label>
                    <select
                      value={category}
                      onChange={(e) => setCategory(e.target.value as DramaCategory)}
                      className="w-full px-3 py-2 rounded-lg bg-[#181924] border border-white/10 text-white text-xs outline-none"
                    >
                      <option value="K-Drama">K-Drama</option>
                      <option value="C-Drama">C-Drama</option>
                      <option value="Asian Movies">Movie</option>
                      <option value="Hollywood / Bollywood">Other Drama</option>
                      <option value="J-Drama">J-Drama</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-zinc-400 mb-1">Audio Track</label>
                    <select
                      value={audio}
                      onChange={(e) => setAudio(e.target.value as AudioType)}
                      className="w-full px-3 py-2 rounded-lg bg-[#181924] border border-white/10 text-white text-xs outline-none"
                    >
                      <option value="Hindi Dubbed">Hindi Dubbed</option>
                      <option value="Fan Dubbed">Fan Dubbed</option>
                      <option value="Original / Eng Sub">Original</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <label className="block text-[11px] font-bold text-zinc-400 mb-1">Release Year</label>
                    <input
                      type="text"
                      value={year}
                      onChange={(e) => setYear(e.target.value)}
                      placeholder="2026"
                      className="w-full px-3 py-2 rounded-lg bg-white/[0.04] border border-white/10 text-white text-xs outline-none focus:border-[#e50914]"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-zinc-400 mb-1">Upload Format</label>
                    <input
                      type="text"
                      value={episodesCount}
                      onChange={(e) => setEpisodesCount(e.target.value)}
                      placeholder="16 Episodes"
                      className="w-full px-3 py-2 rounded-lg bg-white/[0.04] border border-white/10 text-white text-xs outline-none focus:border-[#e50914]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-zinc-400 mb-1">Poster Image URL</label>
                  <input
                    type="url"
                    value={poster}
                    onChange={(e) => setPoster(e.target.value)}
                    placeholder="https://..."
                    className="w-full px-3 py-2 rounded-lg bg-white/[0.04] border border-white/10 text-white text-xs outline-none focus:border-[#e50914]"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-zinc-400 mb-1">Telegram Post Link *</label>
                  <input
                    type="url"
                    required
                    value={telegramUrl}
                    onChange={(e) => setTelegramUrl(e.target.value)}
                    placeholder="https://t.me/c/3730319875/..."
                    className="w-full px-3 py-2 rounded-lg bg-white/[0.04] border border-white/10 text-white text-xs outline-none focus:border-[#e50914]"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-zinc-400 mb-1">Synopsis</label>
                  <textarea
                    rows={2}
                    value={synopsis}
                    onChange={(e) => setSynopsis(e.target.value)}
                    placeholder="Brief plot summary..."
                    className="w-full px-3 py-2 rounded-lg bg-white/[0.04] border border-white/10 text-white text-xs outline-none focus:border-[#e50914]"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSavingSupabase}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#e50914] to-[#ff2b54] text-white text-xs font-black shadow-lg hover:scale-[1.01] active:scale-95 transition-all flex items-center justify-center gap-1.5"
                >
                  <PlusCircle className="w-4 h-4" />
                  <span>{isSavingSupabase ? 'Inserting into Supabase...' : 'Publish to Supabase & Live Portal'}</span>
                </button>
              </form>
            )}

            {/* TAB 3: BROADCAST NOTIFICATIONS & MARQUEE */}
            {activeTab === 'broadcast' && (
              <div className="space-y-4">
                {/* Update Marquee */}
                <div className="p-3.5 rounded-xl bg-white/[0.03] border border-white/5 space-y-2">
                  <label className="block text-xs font-bold text-white">Live Top Notice Ticker</label>
                  <input
                    type="text"
                    value={marqueeDraft}
                    onChange={(e) => setMarqueeDraft(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-white/[0.04] border border-white/10 text-white text-xs outline-none focus:border-[#e50914]"
                  />
                  <button
                    onClick={handleSaveMarquee}
                    className="px-4 py-2 rounded-lg bg-white/[0.08] hover:bg-white/[0.15] text-white text-xs font-bold transition-all"
                  >
                    Update Top Marquee
                  </button>
                </div>

                {/* Broadcast Release Alert */}
                <form onSubmit={handleSendBroadcast} className="p-3.5 rounded-xl bg-white/[0.03] border border-white/5 space-y-2.5">
                  <div className="flex items-center gap-2 text-white font-bold text-xs mb-1">
                    <Megaphone className="w-4 h-4 text-red-400" />
                    <span>Save In-App Alert to Supabase</span>
                  </div>

                  <div>
                    <input
                      type="text"
                      required
                      value={notifTitle}
                      onChange={(e) => setNotifTitle(e.target.value)}
                      placeholder="Alert Heading (e.g. Episode 12 Dropped!)"
                      className="w-full px-3 py-2 rounded-lg bg-white/[0.04] border border-white/10 text-white text-xs outline-none focus:border-[#e50914]"
                    />
                  </div>

                  <div>
                    <textarea
                      required
                      rows={2}
                      value={notifMessage}
                      onChange={(e) => setNotifMessage(e.target.value)}
                      placeholder="Details (e.g. Clean Hindi Audio added on Telegram)..."
                      className="w-full px-3 py-2 rounded-lg bg-white/[0.04] border border-white/10 text-white text-xs outline-none focus:border-[#e50914]"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 rounded-xl bg-[#e50914] text-white text-xs font-black shadow transition-all"
                  >
                    Broadcast & Insert into Supabase
                  </button>
                </form>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
