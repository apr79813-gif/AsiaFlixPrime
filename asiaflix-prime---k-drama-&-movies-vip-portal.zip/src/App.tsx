import React, { useState, useEffect, useMemo, useRef } from 'react';
import { DramaItem, WatchlistEntry, WatchlistStatus, ReleaseNotification, SupportTicket, AudioType } from './types/drama';
import { INITIAL_DRAMAS, INITIAL_NOTIFICATIONS, INITIAL_TICKETS } from './data/initialCatalog';
import { SakuraCanvas } from './components/SakuraCanvas';
import { MarqueeNotice } from './components/MarqueeNotice';
import { Navbar } from './components/Navbar';
import { HeroBanner } from './components/HeroBanner';
import { SpotlightBar } from './components/SpotlightBar';
import { FilterBar } from './components/FilterBar';
import { DramaRow } from './components/DramaRow';
import { DramaCard } from './components/DramaCard';
import { DramaDetailModal } from './components/DramaDetailModal';
import { WatchlistDrawer } from './components/WatchlistDrawer';
import { NotificationDrawer } from './components/NotificationDrawer';
import { RequestDramaModal } from './components/RequestDramaModal';
import { SupportDeskModal } from './components/SupportDeskModal';
import { ArcadeHubModal } from './components/ArcadeHubModal';
import { AdminStudioModal } from './components/AdminStudioModal';
import { PolicySafetySection } from './components/PolicySafetySection';
import { MobileBottomNav } from './components/MobileBottomNav';
import { Footer } from './components/Footer';
import { 
  fetchDramasFromSupabase, 
  fetchNotificationsFromSupabase, 
  getActiveSupabaseUser 
} from './services/supabaseService';

const SHEET_CSV_URL = "https://docs.google.com/spreadsheets/d/e/2PACX-1vR4prDqYUbk87MvTOWLhH9X85aCr9bbVqdI-F6y4raT3sFqvuuPg0o9IkwQ9kzBK4VGFOiDybluNfdm/pub?output=csv";

export default function App() {
  // --- DRAMA CATALOG STATE ---
  const [dramas, setDramas] = useState<DramaItem[]>(() => {
    const saved = localStorage.getItem('asiaflix_custom_dramas');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          const customOnly = parsed.filter((p) => p && p.id && typeof p.id === 'string' && p.id.startsWith('custom-'));
          return [...customOnly, ...INITIAL_DRAMAS];
        }
      } catch (e) {
        console.error('Error loading custom dramas:', e);
      }
    }
    return INITIAL_DRAMAS;
  });

  // --- NOTIFICATIONS STATE ---
  const [notifications, setNotifications] = useState<ReleaseNotification[]>(() => {
    const saved = localStorage.getItem('asiaflix_notifications');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Error parsing notifications:', e);
      }
    }
    return INITIAL_NOTIFICATIONS;
  });

  // --- WATCHLIST STATE ---
  const [watchlist, setWatchlist] = useState<WatchlistEntry[]>(() => {
    const saved = localStorage.getItem('asiaflix_watchlist_v2');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Error parsing watchlist:', e);
      }
    }
    return [
      { dramaId: 'rain-or-shine', status: 'watching', watchedEpisodes: [1, 2, 3], addedAt: Date.now() - 86400000, lastUpdated: Date.now() },
      { dramaId: 'king-the-land', status: 'want_to_watch', watchedEpisodes: [], addedAt: Date.now() - 172800000, lastUpdated: Date.now() },
    ];
  });

  // --- WATCHED EPISODES MAPPING (dramaId -> array of episodeNumber) ---
  const [watchedEpisodesMap, setWatchedEpisodesMap] = useState<Record<string, (number | string)[]>>(() => {
    const saved = localStorage.getItem('asiaflix_watched_episodes_v2');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Error parsing watched episodes:', e);
      }
    }
    return {
      'rain-or-shine': [1, 2, 3],
    };
  });

  // --- SUPPORT TICKETS ---
  const [tickets, setTickets] = useState<SupportTicket[]>(INITIAL_TICKETS);

  // --- MARQUEE NOTICE TEXT ---
  const [marqueeText, setMarqueeText] = useState('Weekend Mega Lineup is Active! New Hindi Dubbed Episodes Dropping Sat & Sun 7:00 PM IST • Zero Ads.');

  // --- SAKURA DRIFT TOGGLE ---
  const [sakuraEnabled, setSakuraEnabled] = useState(true);

  // --- FILTER STATES ---
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedAudio, setSelectedAudio] = useState('all');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedYear, setSelectedYear] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');

  // --- MODAL STATES ---
  const [selectedDrama, setSelectedDrama] = useState<DramaItem | null>(null);
  const [isWatchlistOpen, setIsWatchlistOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isRequestOpen, setIsRequestOpen] = useState(false);
  const [isSupportOpen, setIsSupportOpen] = useState(false);
  const [isArcadeOpen, setIsArcadeOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);

  // Persistent storage effects
  useEffect(() => {
    localStorage.setItem('asiaflix_watchlist_v2', JSON.stringify(watchlist));
  }, [watchlist]);

  useEffect(() => {
    localStorage.setItem('asiaflix_watched_episodes_v2', JSON.stringify(watchedEpisodesMap));
  }, [watchedEpisodesMap]);

  useEffect(() => {
    localStorage.setItem('asiaflix_notifications', JSON.stringify(notifications));
  }, [notifications]);

  // --- SUPABASE AUTH USER STATE ---
  const [supabaseUser, setSupabaseUser] = useState<any | null>(null);

  // Initial sync: Supabase Cloud first, then Sheet fallback
  useEffect(() => {
    getActiveSupabaseUser().then((u) => setSupabaseUser(u));
    syncCatalogAndNotifs();
  }, []);

  const syncCatalogAndNotifs = async () => {
    try {
      const sbDramas = await fetchDramasFromSupabase();
      if (sbDramas && sbDramas.length > 0) {
        const dramaMap = new Map<string, DramaItem>();
        sbDramas.forEach((d) => dramaMap.set(d.id, d));
        INITIAL_DRAMAS.forEach((i) => {
          if (!dramaMap.has(i.id)) dramaMap.set(i.id, i);
        });
        setDramas(Array.from(dramaMap.values()));
      }

      const sbNotifs = await fetchNotificationsFromSupabase();
      if (sbNotifs && sbNotifs.length > 0) {
        setNotifications((prev) => {
          const notifMap = new Map<string, ReleaseNotification>();
          sbNotifs.forEach((n) => notifMap.set(n.id, n));
          prev.forEach((n) => {
            if (!notifMap.has(n.id)) notifMap.set(n.id, n);
          });
          return Array.from(notifMap.values());
        });
      }
    } catch (e) {
      console.warn('Supabase initial fetch caught:', e);
    }

    // Sheet sync fallback
    await fetchGoogleSheetData();
  };

  // Parse CSV function
  const parseCSV = (text: string) => {
    const lines = text.trim().split(/\r\n|\n/);
    const rows: string[][] = [];
    for (const line of lines) {
      const row: string[] = [];
      let inQuotes = false;
      let token = '';
      for (let i = 0; i < line.length; i++) {
        const char = line[i];
        if (char === '"') {
          inQuotes = !inQuotes;
        } else if (char === ',' && !inQuotes) {
          row.push(token.trim());
          token = '';
        } else {
          token += char;
        }
      }
      row.push(token.trim());
      rows.push(row);
    }
    return rows;
  };

  const fetchGoogleSheetData = async () => {
    try {
      const res = await fetch(SHEET_CSV_URL);
      if (res.ok) {
        const text = await res.text();
        const rows = parseCSV(text);
        if (rows.length >= 2) {
          const header = rows[0].map((h) => h.toLowerCase());
          const titleIdx = header.findIndex((h) => h.includes('title') || h.includes('name'));
          const catIdx = header.findIndex((h) => h.includes('category') || h.includes('type'));
          const audioIdx = header.findIndex((h) => h.includes('audio') || h.includes('dub'));
          const posterIdx = header.findIndex((h) => h.includes('poster') || h.includes('image'));
          const telegramIdx = header.findIndex((h) => h.includes('telegram') || h.includes('link'));
          const statusIdx = header.findIndex((h) => h.includes('status'));
          const scheduleIdx = header.findIndex((h) => h.includes('schedule') || h.includes('episode'));
          const noticeIdx = header.findIndex((h) => h.includes('notice'));

          if (rows[1][noticeIdx] && rows[1][noticeIdx].trim()) {
            setMarqueeText(rows[1][noticeIdx].trim());
          }

          const parsedDramasMap = new Map<string, DramaItem>();

          for (let r = 1; r < rows.length; r++) {
            const row = rows[r];
            const title = row[titleIdx >= 0 ? titleIdx : 0];
            if (!title || !title.trim()) continue;

            const category = row[catIdx >= 0 ? catIdx : 1] || 'K-Drama';
            const audio = (row[audioIdx >= 0 ? audioIdx : 2] || 'Hindi Dubbed') as AudioType;
            const poster = row[posterIdx >= 0 ? posterIdx : 3];
            const telegram = row[telegramIdx >= 0 ? telegramIdx : 4] || 'https://t.me/+yJH68LvfrT9hZDVl';
            const status = row[statusIdx >= 0 ? statusIdx : 5] || 'Now Streaming (Ongoing)';
            const schedule = row[scheduleIdx >= 0 ? scheduleIdx : 6] || '16 Episodes';

            const cleanTitle = title.trim();
            const normalizedTitle = cleanTitle.toLowerCase().replace(/\s*\(\d{4}\)/g, '').replace(/[^a-z0-9]/g, ' ').trim();

            // Find matching initial drama by title
            const existing = INITIAL_DRAMAS.find((d) => {
              const existingNorm = d.title.toLowerCase().replace(/\s*\(\d{4}\)/g, '').replace(/[^a-z0-9]/g, ' ').trim();
              return existingNorm === normalizedTitle || existingNorm.includes(normalizedTitle) || normalizedTitle.includes(existingNorm);
            });

            const dramaId = existing ? existing.id : `sheet-${cleanTitle.toLowerCase().replace(/[^a-z0-9]/g, '-')}`;

            if (parsedDramasMap.has(dramaId)) {
              // MERGE multiple audio rows into single drama card to eliminate duplicates
              const existingEntry = parsedDramasMap.get(dramaId)!;
              if (audio && !existingEntry.availableAudios.includes(audio)) {
                existingEntry.availableAudios.push(audio);
              }
              if (telegram && telegram !== 'https://t.me/+yJH68LvfrT9hZDVl' && (!existingEntry.telegramUrl || existingEntry.telegramUrl === 'https://t.me/+yJH68LvfrT9hZDVl')) {
                existingEntry.telegramUrl = telegram;
              }
              if (poster && poster.startsWith('http') && (!existingEntry.poster || existingEntry.poster.includes('unsplash'))) {
                existingEntry.poster = poster;
                existingEntry.backdrop = poster;
              }
              if (telegram) {
                const epExists = existingEntry.episodes.some((e) => e.telegramUrl === telegram && e.audio === audio);
                if (!epExists) {
                  existingEntry.episodes.push({
                    id: `ep-${dramaId}-${existingEntry.episodes.length + 1}`,
                    episodeNumber: existingEntry.episodes.length + 1,
                    title: `${cleanTitle} (${audio})`,
                    audio,
                    telegramUrl: telegram,
                    duration: schedule || 'Full',
                    quality: '1080p FHD',
                  });
                }
              }
              continue;
            }

            // Determine release year from title or row
            const yearMatch = cleanTitle.match(/\b(20\d\d)\b/);
            const releaseYear = existing?.releaseYear || (yearMatch ? parseInt(yearMatch[1]) : 2026);

            // Map category safely
            let dramaCategory = existing?.category;
            if (!dramaCategory) {
              const catLower = category.toLowerCase();
              if (catLower.includes('c-drama') || catLower.includes('chinese')) dramaCategory = 'C-Drama';
              else if (catLower.includes('movie') || catLower.includes('film')) dramaCategory = 'Asian Movies';
              else if (catLower.includes('bolly') || catLower.includes('holly')) dramaCategory = 'Hollywood / Bollywood';
              else if (catLower.includes('j-drama') || catLower.includes('japanese')) dramaCategory = 'J-Drama';
              else dramaCategory = 'K-Drama';
            }

            parsedDramasMap.set(dramaId, {
              id: dramaId,
              title: cleanTitle,
              originalTitle: existing?.originalTitle,
              category: dramaCategory,
              releaseYear,
              status: (status.includes('Completed') ? 'Completed (Full Series)' : status.includes('Coming') || status.includes('Upcoming') ? 'Coming Soon' : 'Now Streaming (Ongoing)'),
              rating: existing?.rating || 9.2,
              poster: (poster && poster.startsWith('http')) ? poster : existing?.poster || 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=700',
              backdrop: existing?.backdrop || (poster && poster.startsWith('http') ? poster : 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1400'),
              synopsis: existing?.synopsis || `Stream ${cleanTitle} in clean audio on AsiaFlix Prime Private Channel.`,
              cast: existing?.cast || ['AsiaFlix Exclusive'],
              tags: existing?.tags || ['Asian Drama', audio],
              scheduleInfo: schedule || existing?.scheduleInfo || '2026 Release',
              availableAudios: existing?.availableAudios ? Array.from(new Set([...existing.availableAudios, audio])) : [audio],
              defaultAudio: audio || existing?.defaultAudio || 'Hindi Dubbed',
              isFeatured: existing?.isFeatured || false,
              isTrending: existing?.isTrending || true,
              totalEpisodes: existing?.totalEpisodes || 16,
              qualityBadge: '1080p FHD',
              telegramUrl: telegram,
              episodes: existing?.episodes || [
                {
                  id: `ep-${dramaId}-1`,
                  episodeNumber: 'Full Pack',
                  title: `${cleanTitle} 1080p FHD`,
                  audio,
                  telegramUrl: telegram,
                  duration: schedule,
                  quality: '1080p FHD',
                  isMerged: true,
                },
              ],
            });
          }

          // Ensure all rich initial dramas are also included if not in sheet
          INITIAL_DRAMAS.forEach((initial) => {
            if (!parsedDramasMap.has(initial.id)) {
              parsedDramasMap.set(initial.id, initial);
            }
          });

          const uniqueParsed = Array.from(parsedDramasMap.values());
          if (uniqueParsed.length > 0) {
            setDramas(uniqueParsed);
          }
        }
      }
    } catch (err) {
      console.warn('Google Sheets live sync notice: using verified catalog cache', err);
    }
  };

  // --- WATCHLIST ACTIONS ---
  const handleToggleWatchlist = (drama: DramaItem, newStatus?: WatchlistStatus) => {
    setWatchlist((prev) => {
      const existing = prev.find((w) => w.dramaId === drama.id);
      if (existing) {
        if (newStatus && existing.status !== newStatus) {
          // Update status
          return prev.map((w) => (w.dramaId === drama.id ? { ...w, status: newStatus, lastUpdated: Date.now() } : w));
        }
        // Remove if clicking toggle without specific new status
        return prev.filter((w) => w.dramaId !== drama.id);
      } else {
        // Add new
        return [
          {
            dramaId: drama.id,
            status: newStatus || 'want_to_watch',
            watchedEpisodes: [],
            addedAt: Date.now(),
            lastUpdated: Date.now(),
          },
          ...prev,
        ];
      }
    });
  };

  const handleRemoveFromWatchlist = (dramaId: string) => {
    setWatchlist((prev) => prev.filter((w) => w.dramaId !== dramaId));
  };

  const handleUpdateWatchlistStatus = (dramaId: string, status: WatchlistStatus) => {
    setWatchlist((prev) =>
      prev.map((w) => (w.dramaId === dramaId ? { ...w, status, lastUpdated: Date.now() } : w))
    );
  };

  const handleToggleEpisodeWatched = (dramaId: string, episodeNum: number | string) => {
    setWatchedEpisodesMap((prev) => {
      const currentList = prev[dramaId] || [];
      const isAlready = currentList.includes(episodeNum);
      const updatedList = isAlready
        ? currentList.filter((n) => n !== episodeNum)
        : [...currentList, episodeNum];

      // Also ensure it is in the watchlist as 'watching'
      setWatchlist((wList) => {
        const found = wList.find((w) => w.dramaId === dramaId);
        if (!found) {
          return [
            {
              dramaId,
              status: 'watching',
              watchedEpisodes: updatedList,
              addedAt: Date.now(),
              lastUpdated: Date.now(),
            },
            ...wList,
          ];
        } else {
          return wList.map((w) =>
            w.dramaId === dramaId
              ? {
                  ...w,
                  status: w.status === 'want_to_watch' ? 'watching' : w.status,
                  watchedEpisodes: updatedList,
                  lastUpdated: Date.now(),
                }
              : w
          );
        }
      });

      return {
        ...prev,
        [dramaId]: updatedList,
      };
    });
  };

  const isDramaWatchlisted = (dramaId: string) => {
    return watchlist.some((w) => w.dramaId === dramaId);
  };

  const getDramaWatchlistStatus = (dramaId: string): WatchlistStatus => {
    const item = watchlist.find((w) => w.dramaId === dramaId);
    return item ? item.status : 'want_to_watch';
  };

  // --- NOTIFICATIONS ACTIONS ---
  const handleMarkAllNotifsAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
  };

  const handleSelectNotification = (notif: ReleaseNotification) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === notif.id ? { ...n, isRead: true } : n))
    );
    if (notif.dramaId) {
      const drama = dramas.find((d) => d.id === notif.dramaId);
      if (drama) setSelectedDrama(drama);
    }
  };

  const handleAddNotification = (newNotif: ReleaseNotification) => {
    setNotifications((prev) => [newNotif, ...prev]);
  };

  const handleAddDrama = (newDrama: DramaItem) => {
    setDramas((prev) => {
      const updated = [newDrama, ...prev];
      localStorage.setItem('asiaflix_custom_dramas', JSON.stringify(updated));
      return updated;
    });
  };

  // --- FILTERED DRAMAS ENGINE ---
  const filteredDramas = useMemo(() => {
    const list = dramas.filter((d: DramaItem) => {
      // 1. Search Query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchesTitle = d.title.toLowerCase().includes(q);
        const matchesOriginal = d.originalTitle?.toLowerCase().includes(q) || false;
        const matchesCast = d.cast?.some((c) => c.toLowerCase().includes(q)) || false;
        const matchesTags = d.tags?.some((t) => t.toLowerCase().includes(q)) || false;
        if (!matchesTitle && !matchesOriginal && !matchesCast && !matchesTags) {
          return false;
        }
      }

      // 2. Audio Filter
      if (selectedAudio !== 'all') {
        const hasAudio = d.availableAudios.some((a) => a.toLowerCase().includes(selectedAudio.toLowerCase()));
        if (!hasAudio && !d.defaultAudio.toLowerCase().includes(selectedAudio.toLowerCase())) {
          return false;
        }
      }

      // 3. Category Filter
      if (selectedCategory !== 'all') {
        if (d.category !== selectedCategory) {
          return false;
        }
      }

      // 4. Release Year Filter
      if (selectedYear !== 'all') {
        if (d.releaseYear.toString() !== selectedYear) {
          return false;
        }
      }

      // 5. Status Filter
      if (selectedStatus !== 'all') {
        if (d.status !== selectedStatus) {
          return false;
        }
      }

      return true;
    });

    // Guarantee unique IDs across all search and filter views
    const seen = new Set<string>();
    return list.filter((d: DramaItem) => {
      if (!d || !d.id || seen.has(d.id)) return false;
      seen.add(d.id);
      return true;
    });
  }, [dramas, searchQuery, selectedAudio, selectedCategory, selectedYear, selectedStatus]);

  // Featured dramas for Hero Carousel (unique by ID)
  const featuredDramas = useMemo(() => {
    const seen = new Set<string>();
    const list = dramas.filter((d) => (d.isFeatured || d.isSpotlight) && !seen.has(d.id) && seen.add(d.id));
    return list.length > 0 ? list : Array.from(new Map(dramas.map((d) => [d.id, d])).values()).slice(0, 4);
  }, [dramas]);

  // Top Trending Spotlight items (unique by ID)
  const spotlightDramas = useMemo(() => {
    const seen = new Set<string>();
    return dramas.filter((d) => (d.isSpotlight || d.isTrending) && !seen.has(d.id) && seen.add(d.id)).slice(0, 4);
  }, [dramas]);

  // Continue Watching dramas
  const continueWatchingDramas = useMemo(() => {
    const watchingIds = watchlist
      .filter((w) => w.status === 'watching' || w.watchedEpisodes.length > 0)
      .map((w) => w.dramaId);
    return dramas.filter((d) => watchingIds.includes(d.id));
  }, [dramas, watchlist]);

  // Recommended for You (Smart suggestion engine)
  const recommendedDramas = useMemo(() => {
    // If user has watchlist entries, suggest similar genres
    const preferredGenres = new Set<string>();
    watchlist.forEach((w) => {
      const d = dramas.find((item) => item.id === w.dramaId);
      if (d) {
        d.tags.forEach((t) => preferredGenres.add(t.toLowerCase()));
      }
    });

    if (preferredGenres.size > 0) {
      const recs = dramas.filter((d) => {
        if (watchlist.some((w) => w.dramaId === d.id)) return false;
        return d.tags.some((t) => preferredGenres.has(t.toLowerCase())) || d.rating >= 9.2;
      });
      if (recs.length >= 3) return recs.slice(0, 10);
    }

    // Default top rated Hindi Dubbed recommendation
    return dramas.filter((d) => d.rating >= 9.0).slice(0, 10);
  }, [dramas, watchlist]);

  // Section Collections
  const comingSoonDramas = useMemo(() => dramas.filter((d) => d.status.includes('Coming Soon')), [dramas]);
  const trendingDramas = useMemo(() => dramas.filter((d) => d.isTrending || d.status.includes('Ongoing')), [dramas]);
  const ongoingDramas = useMemo(() => dramas.filter((d) => d.status.includes('Ongoing')), [dramas]);
  const kdramaList = useMemo(() => dramas.filter((d) => d.category === 'K-Drama'), [dramas]);
  const cdramaList = useMemo(() => dramas.filter((d) => d.category === 'C-Drama'), [dramas]);
  const asianMoviesList = useMemo(() => dramas.filter((d) => d.category === 'Asian Movies'), [dramas]);
  const hollyBollyList = useMemo(() => dramas.filter((d) => d.category === 'Hollywood / Bollywood'), [dramas]);
  const completedList = useMemo(() => dramas.filter((d) => d.status.includes('Completed')), [dramas]);

  const searchInputRef = useRef<HTMLInputElement>(null);
  const handleFocusSearch = () => {
    window.scrollTo({ top: 400, behavior: 'smooth' });
  };

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  return (
    <div className="min-h-screen bg-[#08080c] text-white flex flex-col relative selection:bg-[#e50914] selection:text-white">
      {/* Sakura Petal Floating Canvas */}
      <SakuraCanvas enabled={sakuraEnabled} />

      {/* Top Notice Running Marquee */}
      <MarqueeNotice noticeText={marqueeText} isLiveSynced={true} />

      {/* Header / Navbar */}
      <Navbar
        unreadNotifsCount={unreadCount}
        watchlistCount={watchlist.length}
        sakuraEnabled={sakuraEnabled}
        onToggleSakura={() => setSakuraEnabled(!sakuraEnabled)}
        onOpenNotifications={() => setIsNotificationsOpen(true)}
        onOpenWatchlist={() => setIsWatchlistOpen(true)}
        onOpenArcade={() => setIsArcadeOpen(true)}
        onOpenSupport={() => setIsSupportOpen(true)}
        onOpenRequest={() => setIsRequestOpen(true)}
        onOpenAdmin={() => setIsAdminOpen(true)}
      />

      {/* Cinematic Hero Banner Carousel */}
      <HeroBanner
        featuredDramas={featuredDramas}
        onSelectDrama={(drama) => setSelectedDrama(drama)}
        onToggleWatchlist={handleToggleWatchlist}
        isWatchlisted={isDramaWatchlisted}
      />

      {/* Top Trending Spotlight Strip */}
      <SpotlightBar
        spotlightDramas={spotlightDramas}
        onSelectDrama={(drama) => setSelectedDrama(drama)}
      />

      {/* Catalog Search & Multi-Track Audio Filter Bar */}
      <FilterBar
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        selectedAudio={selectedAudio}
        onSelectAudio={setSelectedAudio}
        selectedCategory={selectedCategory}
        onSelectCategory={setSelectedCategory}
        selectedYear={selectedYear}
        onSelectYear={setSelectedYear}
        selectedStatus={selectedStatus}
        onSelectStatus={setSelectedStatus}
        totalFilteredCount={filteredDramas.length}
      />

      {/* MAIN CATALOG CONTENT */}
      <main className="flex-1 pb-16">
        {/* If search query or specific filter is active: show isolated instant search results */}
        {searchQuery.trim() !== '' || selectedAudio !== 'all' || selectedCategory !== 'all' || selectedYear !== 'all' || selectedStatus !== 'all' ? (
          <section className="max-w-7xl mx-auto px-4 sm:px-6 mb-12">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-xl font-black text-white flex items-center gap-2">
                  <span>Filtered Releases</span>
                  <span className="text-xs font-bold text-zinc-400 bg-white/10 px-2.5 py-0.5 rounded-full">
                    {filteredDramas.length} Results
                  </span>
                </h2>
                <p className="text-xs text-zinc-400 mt-1">
                  Matching: {searchQuery ? `"${searchQuery}" · ` : ''}
                  {selectedAudio !== 'all' ? `${selectedAudio} · ` : ''}
                  {selectedCategory !== 'all' ? `${selectedCategory} · ` : ''}
                  {selectedYear !== 'all' ? `Year ${selectedYear} · ` : ''}
                  {selectedStatus !== 'all' ? `${selectedStatus}` : ''}
                </p>
              </div>

              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedAudio('all');
                  setSelectedCategory('all');
                  setSelectedYear('all');
                  setSelectedStatus('all');
                }}
                className="text-xs font-bold text-red-400 hover:text-red-300 underline"
              >
                Reset All Filters
              </button>
            </div>

            {filteredDramas.length === 0 ? (
              <div className="py-20 text-center bg-white/[0.02] border border-white/5 rounded-2xl p-8">
                <p className="text-base font-bold text-zinc-300">No drama or movie found matching your criteria.</p>
                <p className="text-xs text-zinc-500 mt-1">
                  Try searching for another title, or click "Request Drama" to ask the admin to upload it to the VIP channel!
                </p>
                <button
                  onClick={() => setIsRequestOpen(true)}
                  className="mt-4 px-4 py-2 rounded-xl bg-[#e50914] text-white text-xs font-black shadow-lg"
                >
                  🎬 Request This Drama Now
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
                {filteredDramas.map((drama) => (
                  <DramaCard
                    key={drama.id}
                    drama={drama}
                    onSelect={(d) => setSelectedDrama(d)}
                    onToggleWatchlist={handleToggleWatchlist}
                    isWatchlisted={isDramaWatchlisted(drama.id)}
                  />
                ))}
              </div>
            )}
          </section>
        ) : (
          /* STANDARD CURATED OTT ROWS */
          <div className="space-y-4">
            {/* 1. Continue Watching (if user has active progress) */}
            {continueWatchingDramas.length > 0 && (
              <DramaRow
                id="sec-continue-watching"
                title="Continue Watching"
                subtitle="Pick up where you left off"
                icon="▶️"
                dramas={continueWatchingDramas}
                onSelectDrama={(d) => setSelectedDrama(d)}
                onToggleWatchlist={handleToggleWatchlist}
                isWatchlisted={isDramaWatchlisted}
              />
            )}

            {/* 2. Personalized Recommended for You */}
            <DramaRow
              id="sec-recommended"
              title="Recommended for You"
              subtitle="Personalized VIP picks tailored to your taste"
              icon="🎯"
              dramas={recommendedDramas}
              onSelectDrama={(d) => setSelectedDrama(d)}
              onToggleWatchlist={handleToggleWatchlist}
              isWatchlisted={isDramaWatchlisted}
            />

            {/* 3. Coming Soon & Premieres */}
            <DramaRow
              id="sec-coming-soon"
              title="Coming Soon & Upcoming Premieres"
              subtitle="Upcoming Asian blockbuster premieres for 2026"
              icon="🌸🔥"
              dramas={comingSoonDramas}
              onSelectDrama={(d) => setSelectedDrama(d)}
              onToggleWatchlist={handleToggleWatchlist}
              isWatchlisted={isDramaWatchlisted}
            />

            {/* 4. Trending Now */}
            <DramaRow
              id="sec-trending"
              title="Trending Now (Top VIP Binge Picks)"
              subtitle="Most popular series with high bit-rate audio"
              icon="🐰🔥"
              dramas={trendingDramas}
              onSelectDrama={(d) => setSelectedDrama(d)}
              onToggleWatchlist={handleToggleWatchlist}
              isWatchlisted={isDramaWatchlisted}
            />

            {/* 5. Ongoing Drops & Latest */}
            <DramaRow
              id="sec-ongoing"
              title="Ongoing Drops & Latest Releases"
              subtitle="Fresh episodes uploaded every Saturday & Sunday 7:00 PM"
              icon="✨🆕"
              dramas={ongoingDramas}
              onSelectDrama={(d) => setSelectedDrama(d)}
              onToggleWatchlist={handleToggleWatchlist}
              isWatchlisted={isDramaWatchlisted}
            />

            {/* 6. K-Dramas (Korean) */}
            <DramaRow
              id="sec-kdrama"
              title="K-Dramas (Korean)"
              subtitle="Heartwarming romances, thrilling revenge, and comedy in clean Hindi audio"
              icon="🇰🇷🌸"
              dramas={kdramaList}
              onSelectDrama={(d) => setSelectedDrama(d)}
              onToggleWatchlist={handleToggleWatchlist}
              isWatchlisted={isDramaWatchlisted}
            />

            {/* 7. C-Dramas (Chinese) */}
            <DramaRow
              id="sec-cdrama"
              title="C-Dramas (Chinese)"
              subtitle="Top sweet romance, wuxia, and modern acoustic series"
              icon="🇨🇳✨"
              dramas={cdramaList}
              onSelectDrama={(d) => setSelectedDrama(d)}
              onToggleWatchlist={handleToggleWatchlist}
              isWatchlisted={isDramaWatchlisted}
            />

            {/* 8. Asian Blockbuster Movies */}
            <DramaRow
              id="sec-asian-movies"
              title="Asian Movies & Blockbusters in Hindi Dubbed 1080p"
              subtitle="Complete full-length cinematic experiences"
              icon="🎬🍿"
              dramas={asianMoviesList.length > 0 ? asianMoviesList : dramas.filter((d) => d.totalEpisodes === 1)}
              onSelectDrama={(d) => setSelectedDrama(d)}
              onToggleWatchlist={handleToggleWatchlist}
              isWatchlisted={isDramaWatchlisted}
            />

            {/* 9. Hollywood & Bollywood in Hindi Dubbed */}
            <DramaRow
              id="sec-holly-bolly"
              title="Hollywood & Bollywood in Hindi Dubbed"
              subtitle="Epic action and supernatural adventures"
              icon="🍿🎬"
              dramas={hollyBollyList}
              onSelectDrama={(d) => setSelectedDrama(d)}
              onToggleWatchlist={handleToggleWatchlist}
              isWatchlisted={isDramaWatchlisted}
            />

            {/* 10. Completed Full Series (Binge Ready) */}
            <DramaRow
              id="sec-completed"
              title="Completed Full Series (Binge Ready)"
              subtitle="All episodes available for non-stop weekend marathon"
              icon="🟢✨"
              dramas={completedList}
              onSelectDrama={(d) => setSelectedDrama(d)}
              onToggleWatchlist={handleToggleWatchlist}
              isWatchlisted={isDramaWatchlisted}
            />
          </div>
        )}

        {/* Channel Policy & Safety Section */}
        <PolicySafetySection />
      </main>

      {/* Footer */}
      <Footer
        onOpenSupport={() => setIsSupportOpen(true)}
        onOpenRequest={() => setIsRequestOpen(true)}
        onOpenAdmin={() => setIsAdminOpen(true)}
      />

      {/* Mobile Bottom Navigation */}
      <MobileBottomNav
        onGoHome={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
        onFocusSearch={handleFocusSearch}
        onOpenWatchlist={() => setIsWatchlistOpen(true)}
        onOpenArcade={() => setIsArcadeOpen(true)}
        onOpenSupport={() => setIsSupportOpen(true)}
        watchlistCount={watchlist.length}
      />

      {/* --- MODALS & DRAWERS --- */}

      {/* 1. Drama Detail Modal */}
      {selectedDrama && (
        <DramaDetailModal
          drama={selectedDrama}
          onClose={() => setSelectedDrama(null)}
          onToggleWatchlist={handleToggleWatchlist}
          isWatchlisted={isDramaWatchlisted(selectedDrama.id)}
          watchlistStatus={getDramaWatchlistStatus(selectedDrama.id)}
          watchedEpisodes={watchedEpisodesMap[selectedDrama.id] || []}
          onToggleEpisodeWatched={handleToggleEpisodeWatched}
        />
      )}

      {/* 2. Watchlist Drawer */}
      <WatchlistDrawer
        isOpen={isWatchlistOpen}
        onClose={() => setIsWatchlistOpen(false)}
        watchlist={watchlist}
        allDramas={dramas}
        onSelectDrama={(d) => setSelectedDrama(d)}
        onRemoveFromWatchlist={handleRemoveFromWatchlist}
        onUpdateStatus={handleUpdateWatchlistStatus}
        supabaseUser={supabaseUser}
        onUserChange={setSupabaseUser}
      />

      {/* 3. Notifications Drawer */}
      <NotificationDrawer
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
        notifications={notifications}
        onMarkAllAsRead={handleMarkAllNotifsAsRead}
        onSelectNotification={handleSelectNotification}
      />

      {/* 4. Request Drama Modal */}
      <RequestDramaModal
        isOpen={isRequestOpen}
        onClose={() => setIsRequestOpen(false)}
      />

      {/* 5. Support Desk Modal */}
      <SupportDeskModal
        isOpen={isSupportOpen}
        onClose={() => setIsSupportOpen(false)}
        tickets={tickets}
      />

      {/* 6. Arcade Hub Modal */}
      <ArcadeHubModal
        isOpen={isArcadeOpen}
        onClose={() => setIsArcadeOpen(false)}
        dramas={dramas}
        onSelectDrama={(d) => setSelectedDrama(d)}
      />

      {/* 7. Admin Studio Modal */}
      <AdminStudioModal
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
        onForceSync={syncCatalogAndNotifs}
        onAddDrama={handleAddDrama}
        onAddNotification={handleAddNotification}
        onUpdateMarquee={setMarqueeText}
        currentMarquee={marqueeText}
      />
    </div>
  );
}
